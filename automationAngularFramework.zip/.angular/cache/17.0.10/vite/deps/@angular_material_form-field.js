import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
} from "./chunk-HATOWAJO.js";
import "./chunk-ZYG4RXTD.js";
import "./chunk-L5RN4ICM.js";
import "./chunk-GPMIKX4C.js";
import "./chunk-7RD4FNXU.js";
import "./chunk-G523G3BC.js";
import "./chunk-5EFZRXYA.js";
import "./chunk-X4DDE2I7.js";
import "./chunk-HXG43FAG.js";
import "./chunk-H3X3WLUV.js";
import "./chunk-KUOPV5YS.js";
import "./chunk-2UXUBMH3.js";
import "./chunk-UB6C7KF6.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
};
//# sourceMappingURL=@angular_material_form-field.js.map
