import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-VB3W3FPL.js";
import "./chunk-HATOWAJO.js";
import "./chunk-22GP33DT.js";
import "./chunk-YOPC5O6U.js";
import "./chunk-GCRL3KXS.js";
import "./chunk-TR6GTFUH.js";
import "./chunk-WMPF3I66.js";
import "./chunk-ZYG4RXTD.js";
import "./chunk-L5RN4ICM.js";
import "./chunk-GPMIKX4C.js";
import "./chunk-7RD4FNXU.js";
import "./chunk-G523G3BC.js";
import "./chunk-5EFZRXYA.js";
import "./chunk-X4DDE2I7.js";
import "./chunk-HXG43FAG.js";
import "./chunk-H3X3WLUV.js";
import "./chunk-KUOPV5YS.js";
import "./chunk-2UXUBMH3.js";
import "./chunk-UB6C7KF6.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
