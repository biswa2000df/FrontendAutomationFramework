import {
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-ZA42CHU6.js";
import "./chunk-ZYG4RXTD.js";
import "./chunk-L5RN4ICM.js";
import "./chunk-GPMIKX4C.js";
import "./chunk-7RD4FNXU.js";
import "./chunk-G523G3BC.js";
import "./chunk-5EFZRXYA.js";
import "./chunk-X4DDE2I7.js";
import "./chunk-HXG43FAG.js";
import "./chunk-H3X3WLUV.js";
import "./chunk-KUOPV5YS.js";
import "./chunk-2UXUBMH3.js";
import "./chunk-UB6C7KF6.js";
export {
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
